exports.id=268,exports.ids=[268],exports.modules={91644:(e,t,s)=>{Promise.resolve().then(s.bind(s,7378))},67010:(e,t,s)=>{Promise.resolve().then(s.bind(s,78143))},64611:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,12994,23)),Promise.resolve().then(s.t.bind(s,96114,23)),Promise.resolve().then(s.t.bind(s,9727,23)),Promise.resolve().then(s.t.bind(s,79671,23)),Promise.resolve().then(s.t.bind(s,41868,23)),Promise.resolve().then(s.t.bind(s,84759,23))},7378:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>M});var a=s(10326),r=s(68686),l=s(35047),i=s(17577),d=s(90434),n=s(24319),h=s(76464),c=s(2634),o=s(42924),p=s(22915),u=s(34565),x=s(48705),m=s(53308),y=s(50732),f=s(36283),v=s(88378),k=s(6507),b=s(39183),g=s(11890);function j(){let e=(0,r.t)(e=>e.user);return(0,a.jsxs)("header",{className:"h-14 bg-white border-b border-border-default flex items-center justify-between px-6",children:[(0,a.jsxs)("div",{className:"flex items-center gap-4",children:[a.jsx("h1",{className:"font-title-lg text-text-primary",children:"Orbit"}),(0,a.jsxs)("nav",{className:"hidden md:flex items-center gap-1 text-sm text-text-secondary",children:[a.jsx(d.default,{href:"/",className:"hover:text-text-primary",children:"工作台"}),a.jsx("span",{className:"text-text-muted",children:"/"}),a.jsx("span",{className:"text-text-primary",children:"当前页面"})]})]}),(0,a.jsxs)("div",{className:"flex items-center gap-4",children:[(0,a.jsxs)("div",{className:"flex items-center gap-2 text-sm",children:[a.jsx(p.Z,{size:16,className:"text-text-muted"}),a.jsx("select",{className:"input h-8 text-sm w-40",children:a.jsx("option",{children:"默认店铺"})})]}),(0,a.jsxs)("button",{className:"relative p-2 rounded-md hover:bg-surface-hover",children:[a.jsx(k.Z,{size:18,className:"text-text-secondary"}),a.jsx("span",{className:"absolute top-1 right-1 w-2 h-2 rounded-full bg-danger-500"})]}),(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[a.jsx("div",{className:"w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-sm font-medium",children:e?.email?.[0]?.toUpperCase()||"U"}),a.jsx("span",{className:"text-sm text-text-secondary hidden sm:block",children:e?.email||"User"})]})]})]})}let Z=[{title:"总览",items:[{href:"/",label:"工作台",icon:n.Z},{href:"/reports",label:"数据报表",icon:h.Z}]},{title:"投放管理",items:[{href:"/advertising/campaigns",label:"广告管理",icon:c.Z},{href:"/rules",label:"规则管理",icon:o.Z}]},{title:"资产",items:[{href:"/stores",label:"店铺",icon:p.Z},{href:"/accounts",label:"广告账户",icon:u.Z},{href:"/products",label:"商品",icon:x.Z},{href:"/feeds",label:"Feed",icon:m.Z}]},{title:"AI 能力",items:[{href:"/agent",label:"Agent 对话",icon:y.Z},{href:"/agent/cards",label:"待确认动作",icon:f.Z}]},{title:"系统",items:[{href:"/settings",label:"系统设置",icon:v.Z},{href:"/notifications",label:"通知中心",icon:k.Z},{href:"/workspaces",label:"工作区管理",icon:x.Z},{href:"/settings/providers",label:"Provider 配置",icon:v.Z}]}];function w({children:e}){let[t,s]=(0,i.useState)(!1);return(0,l.useRouter)(),(0,a.jsxs)("div",{className:"flex min-h-screen bg-surface-page",children:[(0,a.jsxs)("aside",{className:`fixed inset-y-0 left-0 z-10 bg-white border-r border-border-default transition-all duration-200 ${t?"w-16":"w-60"}`,children:[(0,a.jsxs)("div",{className:"flex h-14 items-center justify-between px-4 border-b border-border-default",children:[!t&&a.jsx("span",{className:"font-title-lg text-text-primary",children:"Orbit"}),a.jsx("button",{onClick:()=>s(!t),className:"p-1.5 rounded-md hover:bg-surface-hover text-text-muted",children:t?a.jsx(b.Z,{size:18}):a.jsx(g.Z,{size:18})})]}),a.jsx("nav",{className:"p-2 space-y-6 overflow-y-auto",children:Z.map(e=>(0,a.jsxs)("div",{children:[!t&&a.jsx("h3",{className:"px-2 mb-2 text-xs font-semibold text-text-muted uppercase tracking-wider",children:e.title}),a.jsx("div",{className:"space-y-1",children:e.items.map(e=>(0,a.jsxs)(d.default,{href:e.href,className:`flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors ${t?"justify-center":""} hover:bg-surface-hover text-text-secondary`,title:t?e.label:void 0,children:[a.jsx(e.icon,{size:18}),!t&&a.jsx("span",{children:e.label})]},e.href))})]},e.title))})]}),(0,a.jsxs)("div",{className:`flex-1 transition-all duration-200 ${t?"ml-16":"ml-60"}`,children:[a.jsx(j,{}),a.jsx("main",{children:e})]})]})}function M({children:e}){let t=(0,r.t)(e=>e.user);return((0,l.useRouter)(),t)?a.jsx(w,{children:e}):null}},78143:(e,t,s)=>{"use strict";s.d(t,{default:()=>i});var a=s(10326),r=s(47058),l=s(17577);function i({children:e}){let[t]=(0,l.useState)(()=>new r.QueryClient({defaultOptions:{queries:{staleTime:3e4,gcTime:3e5,refetchOnWindowFocus:!1,retry:1}}})),[s,i]=(0,l.useState)(!1);return s?a.jsx(r.QueryClientProvider,{client:t,children:e}):a.jsx(a.Fragment,{children:e})}},6824:(e,t,s)=>{"use strict";async function a(e,t={}){let s=`http://localhost:8080/api/v1${e}`,a={"Content-Type":"application/json",...t.headers},r=await fetch(s,{...t,headers:a});if(401===r.status)throw Error("Unauthorized");if(403===r.status)throw Error("Forbidden");if(!r.ok)throw Error((await r.json().catch(()=>({message:"Unknown error"}))).message||`HTTP ${r.status}`);return 204===r.status?null:r.json()}s.d(t,{h:()=>r});let r={get:e=>a(e),post:(e,t)=>a(e,{method:"POST",body:JSON.stringify(t)}),patch:(e,t)=>a(e,{method:"PATCH",body:JSON.stringify(t)}),delete:e=>a(e,{method:"DELETE"})}},68686:(e,t,s)=>{"use strict";s.d(t,{t:()=>l});var a=s(60114),r=s(85251);let l=(0,a.Ue)()((0,r.tJ)(e=>({user:null,accessToken:null,refreshToken:null,setAuth:(t,s,a)=>e({user:t,accessToken:s,refreshToken:a}),logout:()=>e({user:null,accessToken:null,refreshToken:null})}),{name:"orbit-auth",partialize:e=>({user:e.user,accessToken:e.accessToken,refreshToken:e.refreshToken})}))},76557:(e,t,s)=>{"use strict";s.d(t,{Z:()=>i});var a=s(17577),r={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(e,t)=>{let s=(0,a.forwardRef)(({color:s="currentColor",size:i=24,strokeWidth:d=2,absoluteStrokeWidth:n,className:h="",children:c,...o},p)=>(0,a.createElement)("svg",{ref:p,...r,width:i,height:i,stroke:s,strokeWidth:n?24*Number(d)/Number(i):d,className:["lucide",`lucide-${l(e)}`,h].join(" "),...o},[...t.map(([e,t])=>(0,a.createElement)(e,t)),...Array.isArray(c)?c:[c]]));return s.displayName=`${e}`,s}},76464:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("BarChart3",[["path",{d:"M3 3v18h18",key:"1s2lah"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]])},6507:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},50732:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Bot",[["path",{d:"M12 8V4H8",key:"hb8ula"}],["rect",{width:"16",height:"12",x:"4",y:"8",rx:"2",key:"enze0r"}],["path",{d:"M2 14h2",key:"vft8re"}],["path",{d:"M20 14h2",key:"4cs60a"}],["path",{d:"M15 13v2",key:"1xurst"}],["path",{d:"M9 13v2",key:"rq6x2g"}]])},11890:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},39183:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},36283:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},24319:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},42924:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("ListChecks",[["path",{d:"m3 17 2 2 4-4",key:"1jhpwq"}],["path",{d:"m3 7 2 2 4-4",key:"1obspn"}],["path",{d:"M13 6h8",key:"15sg57"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 18h8",key:"oe0vm4"}]])},2634:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]])},48705:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Package",[["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]])},21405:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]])},53308:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Rss",[["path",{d:"M4 11a9 9 0 0 1 9 9",key:"pv89mb"}],["path",{d:"M4 4a16 16 0 0 1 16 16",key:"k0647b"}],["circle",{cx:"5",cy:"19",r:"1",key:"bfqh0e"}]])},88378:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},34565:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("ShoppingBag",[["path",{d:"M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z",key:"hou9p0"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}]])},22915:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.312.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(76557).Z)("Store",[["path",{d:"m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7",key:"ztvudi"}],["path",{d:"M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8",key:"1b2hhj"}],["path",{d:"M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4",key:"2ebpfo"}],["path",{d:"M2 7h20",key:"1fcdvo"}],["path",{d:"M22 7v3a2 2 0 0 1-2 2v0a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12v0a2 2 0 0 1-2-2V7",key:"jon5kx"}]])},68032:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>i,__esModule:()=>l,default:()=>d});var a=s(68570);let r=(0,a.createProxy)(String.raw`E:\develop-space\ads.alaikis.com\apps\web\app\(dashboard)\layout.tsx`),{__esModule:l,$$typeof:i}=r;r.default;let d=(0,a.createProxy)(String.raw`E:\develop-space\ads.alaikis.com\apps\web\app\(dashboard)\layout.tsx#default`)},84752:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>p,metadata:()=>o});var a=s(19510),r=s(20380),l=s.n(r),i=s(68570);let d=(0,i.createProxy)(String.raw`E:\develop-space\ads.alaikis.com\apps\web\app\providers.tsx`),{__esModule:n,$$typeof:h}=d;d.default;let c=(0,i.createProxy)(String.raw`E:\develop-space\ads.alaikis.com\apps\web\app\providers.tsx#default`);s(67272);let o={title:"Orbit - 广告智能中枢",description:"AI Agent 驱动的多平台广告自动化与智能化管理平台"};function p({children:e}){return a.jsx("html",{lang:"zh-CN",children:a.jsx("body",{className:l().variable,children:a.jsx(c,{children:e})})})}},67272:()=>{}};